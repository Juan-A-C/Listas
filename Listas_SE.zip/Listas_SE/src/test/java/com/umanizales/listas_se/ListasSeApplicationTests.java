package com.umanizales.listas_se;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ListasSeApplicationTests {

    @Test
    void contextLoads() {
    }

}

package com.umanizales.listas_se.controller;


import com.umanizales.listas_se.controller.dto.ResponseDTO;
import com.umanizales.listas_se.model.Boy;
import com.umanizales.listas_se.service.ListSeService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(path= "boys")
public class BoysController {

    private ListSeService listSeService;

    @PostMapping
    public ResponseEntity<ResponseDTO> addBoy(@RequestBody Boy boy)
    {
        return listSeService.addBoy(boy);
    }
    @GetMapping
    public ResponseEntity<ResponseDTO> listBoys(){return listSeService,listBoys()}
    {
        return listSeService.listBoys();
    }


    @GetMapping(path = "inivert")
    public ResponseEntity<ResponseDTO> invertLisst()
    {
        return listSeService.invertList();
    }
}


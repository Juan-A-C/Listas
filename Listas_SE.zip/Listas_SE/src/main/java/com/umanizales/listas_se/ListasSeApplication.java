package com.umanizales.listas_se;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ListasSeApplication {

    public static void main(String[] args) {
        SpringApplication.run(ListasSeApplication.class, args);
    }

}

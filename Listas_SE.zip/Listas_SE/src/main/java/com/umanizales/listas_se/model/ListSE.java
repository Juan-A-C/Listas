package com.umanizales.listas_se.model;

import lombok.Data;

@Data
public class ListSE {
    private Node head;

    ///adicionar
    public void add(Boy boy)
    {
        if(head == null)
        {
            head = new Node(boy);
        }
        else
        {
            Node temp = head;
            while(temp.getNext()!=null)
            {
                temp = temp.getNext();
            }
            ///El quedo parado en el ultimo
            temp.setNext(new Node(boy));
        }
    }

    public void invert() {
        if (this.head != null) {
            ListSE listTemp = new ListSE();
            Node temp = this.head;
            while(temp != null)
            {
                listTemp.add(temp.getData());
                temp = temp.getNext();

            }
            this.head = listTemp.getHead();
        }


    }
}

